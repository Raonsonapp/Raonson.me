enum ProfileVisibility {
  public,
  private,
}