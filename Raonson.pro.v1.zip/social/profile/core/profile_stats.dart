class ProfileStats {
  final int posts;
  final int reels;
  final int likes;

  ProfileStats({
    required this.posts,
    required this.reels,
    required this.likes,
  });
}