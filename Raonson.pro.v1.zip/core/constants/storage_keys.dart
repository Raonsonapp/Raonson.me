class StorageKeys {
  static const String authToken = 'auth_token';
  static const String userId = 'user_id';
  static const String themeMode = 'theme_mode';
}