class ApiConstants {
  static const String baseUrl = 'https://api.raonson.app';
}