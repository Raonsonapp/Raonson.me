class BuildInfo {
  static const String version = '1.0.0';
  static const int buildNumber = 1;
}