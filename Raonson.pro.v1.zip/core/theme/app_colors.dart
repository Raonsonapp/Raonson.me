import 'package:flutter/material.dart';

class AppColors {
  static const Color primary = Color(0xFF6A00FF);
  static const Color secondary = Color(0xFF00D4FF);
  static const Color background = Colors.black;
  static const Color textPrimary = Colors.white;
}