import 'permission_types.dart';

class PermissionManager {
  static Future<bool> request(AppPermission permission) async {
    // Real permission logic added later (platform specific)
    return true;
  }
}