enum AppPermission {
  camera,
  microphone,
  storage,
  location,
}