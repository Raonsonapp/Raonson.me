import 'feed_state.dart';
import '../services/feed_service.dart';

class FeedController {
  final FeedService _service = FeedService();
  FeedState state = FeedState();

  Future<void> load() async {
    state = FeedState(loading: true);
    final items = await _service.loadFeed();
    state = FeedState(items: items, loading: false);
  }

  void like(String id) {
    final item = state.items.firstWhere((e) => e.id == id);
    item.likes++;
  }
}