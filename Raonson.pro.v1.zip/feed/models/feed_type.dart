enum FeedType {
  video,
  image,
  text,
}