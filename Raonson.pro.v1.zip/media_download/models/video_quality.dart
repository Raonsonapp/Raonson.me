enum VideoQuality {
  q360,
  q480,
  q720,
  q1080,
}