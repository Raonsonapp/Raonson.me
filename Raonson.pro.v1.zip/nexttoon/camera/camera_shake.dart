class CameraShake {
  final double intensity;
  final Duration duration;

  CameraShake({
    required this.intensity,
    required this.duration,
  });
}