class CameraState {
  double zoom;
  double offsetX;
  double offsetY;

  CameraState({
    this.zoom = 1.0,
    this.offsetX = 0.0,
    this.offsetY = 0.0,
  });
}