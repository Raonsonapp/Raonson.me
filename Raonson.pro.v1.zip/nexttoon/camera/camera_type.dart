enum CameraType {
  static,
  pan,
  zoom,
  shake,
  follow,
  slowMotion,
}