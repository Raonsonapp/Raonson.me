import 'camera_clip.dart';

class CameraRenderState {
  final List<CameraClip> activeClips;

  CameraRenderState({required this.activeClips});
}