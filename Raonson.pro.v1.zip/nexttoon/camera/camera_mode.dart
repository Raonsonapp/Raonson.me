enum CameraMode {
  static,
  follow,
  cinematic,
  shake,
  slowMotion,
}