class SlowMotion {
  final double factor;
  final Duration duration;

  SlowMotion({
    required this.factor,
    required this.duration,
  });
}