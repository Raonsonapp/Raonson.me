enum TimelineEventType {
  sceneStart,
  cameraMove,
  characterAction,
  dialogue,
  sound,
  effect,
  sceneEnd,
}