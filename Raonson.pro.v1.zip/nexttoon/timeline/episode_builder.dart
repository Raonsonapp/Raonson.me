import 'episode_timeline.dart';
import 'scene_timeline.dart';

class EpisodeBuilder {
  EpisodeTimeline build({
    required String episodeId,
    required int sceneCount,
    required Duration targetDuration,
  }) {
    final scenes = <SceneTimeline>[];

    final sceneDuration =
        Duration(seconds: targetDuration.inSeconds ~/ sceneCount);

    for (int i = 0; i < sceneCount; i++) {
      scenes.add(
        SceneTimeline(
          sceneId: 'scene_${i + 1}',
          clips: [],
        ),
      );
    }

    return EpisodeTimeline(
      episodeId: episodeId,
      scenes: scenes,
    );
  }
}