import '../models/anime_scene.dart';

class VoiceEngine {
  Future<void> generateVoice(AnimeScene scene, String lang) async {
    await Future.delayed(const Duration(milliseconds: 200));
  }
}