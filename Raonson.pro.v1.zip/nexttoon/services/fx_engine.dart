import '../models/anime_scene.dart';
import '../models/animation_style.dart';

class FXEngine {
  void applyFX(AnimeScene scene, AnimationStyle style) {
    // demon slayer / solo leveling FX placeholder
  }
}