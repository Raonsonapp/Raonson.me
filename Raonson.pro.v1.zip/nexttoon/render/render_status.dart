enum RenderStatus {
  idle,
  preparing,
  rendering,
  encoding,
  finished,
  failed,
}