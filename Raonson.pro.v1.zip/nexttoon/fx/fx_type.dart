enum FxType {
  slash,
  energyWave,
  fire,
  lightning,
  smoke,
  aura,
  impact,
}