import 'fx_clip.dart';

class FxRenderState {
  final List<FxClip> activeEffects;

  FxRenderState({required this.activeEffects});
}