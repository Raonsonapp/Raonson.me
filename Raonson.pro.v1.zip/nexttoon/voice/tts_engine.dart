import 'voice_track.dart';

class TtsEngine {
  Future<String> synthesize(VoiceTrack track) async {
    // server / AI TTS hook
    return "audio_path.wav";
  }
}