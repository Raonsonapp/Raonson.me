enum VoiceEmotion {
  neutral,
  angry,
  sad,
  happy,
  epic,
  whisper,
}