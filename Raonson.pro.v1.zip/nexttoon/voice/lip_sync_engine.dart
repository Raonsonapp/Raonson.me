import 'lip_sync_frame.dart';

class LipSyncEngine {
  List<LipSyncFrame> generate(String audioPath) {
    // audio analysis
    return [];
  }
}