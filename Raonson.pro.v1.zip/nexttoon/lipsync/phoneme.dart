enum Phoneme {
  A,
  E,
  I,
  O,
  U,
  M,
  F,
  S,
  L,
  R,
  REST,
}