enum AnimationStyle {
  anime2D,
  anime25D,
  anime3D,
  demonSlayerFX,
  soloLevelingFX,
}