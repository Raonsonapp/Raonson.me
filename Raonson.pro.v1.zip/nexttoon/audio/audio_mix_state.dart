import 'audio_track.dart';

class AudioMixState {
  final List<AudioTrack> tracks;

  AudioMixState({required this.tracks});
}