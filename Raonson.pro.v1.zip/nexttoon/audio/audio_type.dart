enum AudioType {
  voice,
  music,
  sfx,
}