class VideoTrack {
  final String path;
  final Duration duration;

  VideoTrack({
    required this.path,
    required this.duration,
  });
}