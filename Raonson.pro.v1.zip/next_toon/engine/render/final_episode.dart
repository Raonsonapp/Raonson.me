class FinalEpisode {
  final String videoPath;
  final bool success;

  FinalEpisode({
    required this.videoPath,
    required this.success,
  });
}