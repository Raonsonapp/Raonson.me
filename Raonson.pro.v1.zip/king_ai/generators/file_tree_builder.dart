class FileTreeBuilder {
  List<String> buildTree(List<String> paths) {
    return paths;
  }
}