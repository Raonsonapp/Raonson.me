enum RenderJobStatus {
  pending,
  rendering,
  completed,
  failed,
}