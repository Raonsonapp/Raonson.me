import 'dart:math';
import 'render_job.dart';

class RenderJobFactory {
  RenderJob create(Map<String, dynamic> payload) {
    final id = "render_${DateTime.now().millisecondsSinceEpoch}_${Random().nextInt(999)}";
    return RenderJob(id: id, payload: payload);
  }
}