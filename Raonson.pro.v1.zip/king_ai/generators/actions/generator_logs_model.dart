class GeneratorLog {
  final DateTime time;
  final String message;

  GeneratorLog({
    required this.time,
    required this.message,
  });
}