enum GeneratorAction {
  start,
  pause,
  resume,
  cancel,
}