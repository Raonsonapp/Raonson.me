enum RenderEngineTarget {
  soraLike,
  animeStudio,
  cinematicAI,
}