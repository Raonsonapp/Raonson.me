enum GenerationStatus {
  idle,
  queued,
  running,
  paused,
  completed,
  failed,
}