enum PipelineStage {
  prompt,
  planning,
  assets,
  logic,
  rendering,
  exporting,
  completed,
  failed,
}