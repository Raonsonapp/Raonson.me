class GeneratedFile {
  final String path;
  final String content;

  GeneratedFile({
    required this.path,
    required this.content,
  });
}