enum KingAIStatus {
  idle,
  running,
  generatingFiles,
  buildingProject,
  completed,
  error,
}