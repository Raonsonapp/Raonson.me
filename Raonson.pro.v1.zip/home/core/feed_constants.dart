class FeedConstants {
  static const int pageSize = 20;
}