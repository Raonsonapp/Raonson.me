import 'lip_sync_frame.dart';

class LipSyncEngine {
  List<LipSyncFrame> generate(String audioPath) {
    // PLACEHOLDER:
    // AI voice analyzer (phoneme → mouth movement)
    return [];
  }
}