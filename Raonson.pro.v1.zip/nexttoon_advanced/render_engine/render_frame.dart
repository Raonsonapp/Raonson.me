class RenderFrame {
  final int index;
  final String imagePath;

  RenderFrame({
    required this.index,
    required this.imagePath,
  });
}