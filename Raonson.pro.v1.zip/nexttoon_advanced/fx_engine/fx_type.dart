enum FXType {
  energyWave,
  slash,
  lightning,
  fire,
  smoke,
  motionBlur,
  impactFlash,
}