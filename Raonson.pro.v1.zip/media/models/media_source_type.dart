// media/models/media_source_type.dart

enum MediaSourceType {
  reel,
  feed,
  movie,
  anime,
  live,
}