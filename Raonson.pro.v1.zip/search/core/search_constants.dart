class SearchConstants {
  static const int debounceMs = 400;

  static const List<String> defaultCategories = [
    'Anime',
    'Games',
    'Music',
    'Movies',
    'Programs',
    'Live',
  ];
}