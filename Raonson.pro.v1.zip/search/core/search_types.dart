enum SearchItemType {
  video,
  reel,
  live,
  profile,
}