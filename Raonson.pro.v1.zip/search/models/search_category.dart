enum SearchCategory {
  all,
  games,
  music,
  sports,
  anime,
  movies,
  programs,
}