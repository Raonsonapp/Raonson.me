enum ContentCategory {
  game,
  music,
  anime,
  sports,
  movies,
  programs,
}